const functions = require('firebase-functions');

var badWords=['fuck','shit','pussy','dick','ass','asshole','mother fucker'];
exports.checkMessage = functions.database.ref('/chat/{pushId}')
.onCreate((snapshot, context) => {
// Grab the current value of what was written to the Realtime Database.
console.log('chatMessage', context.params.pushId, snapshot.val());
let cleanStr = snapshot.val().message;
for(i=0;i<badWords.length;i++){
cleanStr = cleanStr.replace(badWords[i], "*****");
}
return snapshot.ref.child('message').set(cleanStr);
});
exports.checkGameMessage = functions.database.ref('/gameChat/{pushId}')
.onCreate((snapshot, context) => {
// Grab the current value of what was written to the Realtime Database.
console.log('chatMessage', context.params.pushId, snapshot.val());
let cleanGameStr = snapshot.val().message;
for(i=0;i<badWords.length;i++){
cleanGameStr = cleanGameStr.replace(badWords[i], "*****");
}
return snapshot.ref.child('message').set(cleanGameStr);
});
// // Create and Deploy Your First Cloud Functions
// // https://firebase.google.com/docs/functions/write-firebase-functions
//
// exports.helloWorld = functions.https.onRequest((request, response) => {
//  response.send("Hello from Firebase!");
// });
