# chessTemplate
a js chess template
