///// DOM Selectors /////
// Welcome Modal
$setUpDiv = $('#your-setup')
$yourStatusImg = $('#your-status')
$opponentStatusImg = $('#opponent-status')
$opponentName = $('#opponent-name')
$setUpMsg = $('#setup-msg')

// Opening Roll Modal
$openingRollModal = $('#opening-roll')
$openingRollMsg = $('#roll-msg')
$whiteDiceLabel = $('#white-dice-label')
$openingWhiteDice = $('#opening-white-dice')
$blackDiceLabel = $('#black-dice-label')
$openingBlackDice = $('#opening-black-dice')

$gameEndModal = $('#game-end')
$winnerNameSpan = $('#winner-name')
$loserNameSpan = $('#loser-name')
$pcsHomeSpan = $('#pcs-home')
$pcsBarSpan = $('#pcs-bar')

$buttonHolder = $('#button-holder')


///// Read From the Database /////

// "white", "black"
// make sure you very explicitly think about what happens if someone shows up to your game
// while it's in progress. Happily, anyone who hasn't submitted a form doesn't have a myColor.
// Take advantage of that.
var myColor;
var myName;
var flag = 0;
var blackPlayer;

var theirColor;
var theirName;

var gameData;
// This is where firebase data will be stored
//		controllerToken - int
// 		blackName - str
//		whiteName - str
//		lastMove - int

// RULE - before you set an event listener to an object, you explicity clear it of event listeners

// Connect to the whole database with a "reference"
var gamekey3 = localStorage.getItem("keyc");
if (gamekey3 == null) {
	location.href = "../../index.html";
  }
  var game = firebase.database().ref("backgammonData");
  game.once('value', function (snapshot) {
	debugger;
	if (!snapshot.hasChild(gamekey3)) {
	  console.log("No matching game");
	  location.href = "../../index.html";
	}
  });
var databaseRef = firebase.database().ref().child("backgammonData/" +gamekey3)


// Set an event listener to fire every time the data changes
//databaseRef.on("value", dataChangeController)
databaseRef.on("value", function(snapshot){
	gameData = snapshot.val();
	//if(gameData.whiteName == gamekey3)
	//console.log(snapshot.val());
	
databaseRef.on("value", dataChangeController)





function dataChangeController(snapshot) {
	// Update gameData
	gameData = snapshot.val()
	
	switch (gameData.controllerToken) {
		case 0:
			// testing()
			break
		//case 1:
		//	setUpGame()
		//	break
		case 2:
			openingRoll()
			break
		case 3:
			firstMove()
			break
		case 4:
			regularGameplay()
			break
		case 5:
			endGame()
			break
	}
}

///// Just in case: if the game has been sitting unplayed for 45 mins, 
// give new arrivals the option to clear it out 
$( document ).ready(() => {

	setTimeout(() => {
		if (gameData.lastMove && gameData.lastMove + 2700000 < Date.now()) {
			var willReset = confirm('The current game has not been touched in 45 minutes, would you like to reset the board?')
			if (willReset) {
				resetDatabase()
				location.reload()
			}
		}

	}, 1000)

	
}) 

/////New PHASE 1 /////

firebase.auth().onAuthStateChanged(function(user) {
	if (user.uid == gameData.whiteName) {
		myColor = "white"
		theirColor = "black"
		myName = gameData.whiteName
	}
	else{
	myColor = "black";
	theirColor = "white";
	myName = gameData.blackName;
	}
 
});

// both players in the database
	// if this is one of the players, just update their display in the appropriate way
	if(gameData.controllerToken == 0){
	if (myColor === "white") {
		// set black to ready
		$opponentName.text(gameData.blackName)
		$opponentStatusImg.prop('src', './assets/ready_black.png') 
	} else if (myColor === "black"){
		// remove the form, set to ready
		$setUpDiv.append('<p id="your-name" class="name">' + gameData.blackName + '</p>')
		$yourStatusImg.prop('src', './assets/ready_black.png') 
	} 
	// for spectators
/*else {
		// make sure no spectators can alter the database
		//$setUpForm.off() 
		// render the whole damn thing
		//$setUpForm.remove()
	  $setUpDiv.append('<p id="your-name" class="name">' + gameData.blackName + '</p>')
		$yourStatusImg.prop('src', './assets/ready_black.png') 
		$opponentName.text(gameData.whiteName)
		$opponentStatusImg.prop('src', './assets/ready_white.png') 
	} */
	$setUpMsg.text('The game will begin shortly.')
	// in several seconds, move to the opening roll by updating the controller token
	setTimeout(function() {
		gameData.controllerToken = 2
		databaseRef.set(gameData)
	}, 1500)
}

///// PHASE 2 /////

function openingRoll() {
	//switch to the opening roll modal
//	if ($welcomeSetUpModal.hasClass('active-modal')) {
//		$welcomeSetUpModal.removeClass('active-modal')
		$openingRollModal.addClass('active-modal')
	}

	if (myColor === 'white') {
		// set their name
		theirName = gameData.blackName
		// if neither has already delivered a result
		if (!gameData.whiteOpener && !gameData.blackOpener) {
			// display names
			$whiteDiceLabel.text(gameData.whiteName)
			$blackDiceLabel.text(gameData.blackName)
			// make my die active
			$openingWhiteDice.addClass('active')
			// when I click on it, roll it, delivering a result
			$openingWhiteDice.off()
			$openingWhiteDice.on('click', function(e) {

				// Update the lastMove field
				gameData.lastMove = Date.now()
				//roll the dice, set the result appropriately
				$openingWhiteDice.off()
				var result = openingDiceAnimate('white')
				setTimeout(function() {
					var roll = Math.floor(Math.random() * 6) + 1
					gameData.whiteOpener = roll
					$openingWhiteDice.attr('src', './assets/white_' + roll.toString() + '.png')
					$openingWhiteDice.removeClass('active')
					//commit the result
					databaseRef.set(gameData)
				}, 500)
			})
		// if they have already delivered a result
		} else if (!gameData.whiteOpener && !!gameData.blackOpener) {
			// display names
			$whiteDiceLabel.text(gameData.whiteName)
			$blackDiceLabel.text(gameData.blackName)
			// make my die active
			$openingWhiteDice.addClass('active')
			// when I click on it, roll it, delivering a result
			$openingWhiteDice.off()
			$openingWhiteDice.on('click', function(e) {

				// Update the lastMove field
				gameData.lastMove = Date.now()
				//roll the dice, set the result appropriately
				$openingWhiteDice.off()
				var result = openingDiceAnimate('white')
				setTimeout(function() {
					var roll = Math.floor(Math.random() * 6) + 1
					gameData.whiteOpener = roll
					$openingWhiteDice.attr('src', './assets/white_' + roll.toString() + '.png')
					$openingWhiteDice.removeClass('active')
					//commit the result
					databaseRef.set(gameData)
				}, 500)
			})
			// render their roll
			$openingBlackDice.attr('src', './assets/black_' + gameData.blackOpener.toString() + '.png')

		// if we both have already delivered a result
		} else if (!!gameData.whiteOpener && !!gameData.blackOpener) {
			// render their roll
			$openingBlackDice.attr('src', './assets/black_' + gameData.blackOpener.toString() + '.png')
			// if the results are equal, start the hell over
			if (gameData.whiteOpener === gameData.blackOpener) {
				// DOM stuff, everybody has to do this.
				$openingRollMsg.text("It's a tie, roll again.")
				setTimeout(function(){
					$openingWhiteDice.attr('src', './assets/white_naked.png')
					$openingBlackDice.attr('src', './assets/black_naked.png')
					// reset the dice
					gameData.whiteOpener = null
					gameData.blackOpener = null
					gameData.controllerToken = 2
					// commit the changes
					databaseRef.set(gameData)
				}, 500)
			} else if (gameData.whiteOpener > gameData.blackOpener) {
				 	// if white goes first
					$openingRollMsg.text(gameData.whiteName + " goes first!")
					$openingBlackDice.attr('src', './assets/white_' + gameData.blackOpener.toString() + '.png')
					// move to the next controller phase
					setTimeout(function(){
						// hand over important information
						gameData.currentTurn = "white"
						gameData.controllerToken = 3
						// commit the changes
						databaseRef.set(gameData)
					}, 1500)
			} else if(gameData.whiteOpener < gameData.blackOpener) {
				 	// if black goes first
					$openingRollMsg.text(gameData.blackName + " goes first!")
					$openingWhiteDice.attr('src', './assets/black_' + gameData.whiteOpener.toString() + '.png')
				// move to the next controller phase
				setTimeout(function(){
					// hand over important information
					gameData.currentTurn = "black"
					gameData.controllerToken = 3
					// commit the changes
					databaseRef.set(gameData)
				}, 1500)
			}
		}
	} else if (myColor === 'black') {
		// set their name
		theirName = gameData.whiteName
		// if neither has already delivered a result
		if (!gameData.whiteOpener && !gameData.blackOpener) {
			// display names
			$whiteDiceLabel.text(gameData.whiteName)
			$blackDiceLabel.text(gameData.blackName)
			// make my die active
			$openingBlackDice.addClass('active')
			// when I click on it, roll it, delivering a result
			$openingBlackDice.off()
			$openingBlackDice.on('click', function(e) {


				// Update the lastMove field
				gameData.lastMove = Date.now()
				//roll the dice, set the result appropriately
				$openingBlackDice.off()
				var result = openingDiceAnimate('black')
				setTimeout(function() {
					var roll = Math.floor(Math.random() * 6) + 1
					gameData.blackOpener = roll
					$openingBlackDice.attr('src', './assets/black_' + roll.toString() + '.png')
					$openingBlackDice.removeClass('active')
					//commit the result
					databaseRef.set(gameData)
				}, 500)
			})
		// if they have already delivered a result
		} else if (!!gameData.whiteOpener && !gameData.blackOpener) {
			// display names
			$whiteDiceLabel.text(gameData.whiteName)
			$blackDiceLabel.text(gameData.blackName)
			// make my die active
			$openingBlackDice.addClass('active')
			// when I click on it, roll it, delivering a result
			$openingBlackDice.off()
			$openingBlackDice.on('click', function(e) {


				// Update the lastMove field
				gameData.lastMove = Date.now()
				//roll the dice, set the result appropriately
				$openingBlackDice.off()
				var result = openingDiceAnimate('black')
				setTimeout(function() {
					var roll = Math.floor(Math.random() * 6) + 1
					gameData.blackOpener = roll
					$openingBlackDice.attr('src', './assets/black_' + roll.toString() + '.png')
					$openingBlackDice.removeClass('active')
					//commit the result
					databaseRef.set(gameData)
				}, 500)
			})
			// render their roll
			$openingWhiteDice.attr('src', './assets/white_' + gameData.whiteOpener.toString() + '.png')

		// if we both have already delivered a result
		} else if (!!gameData.whiteOpener && !!gameData.blackOpener) {
			// render their roll
			$openingWhiteDice.attr('src', './assets/white_' + gameData.whiteOpener.toString() + '.png')
			// if the results are equal, start the hell over
			if (gameData.whiteOpener === gameData.blackOpener) {
				// DOM stuff, everybody has to do this.
				$openingRollMsg.text("It's a tie, roll again.")
				setTimeout(function(){
					$openingWhiteDice.attr('src', './assets/white_naked.png')
					$openingBlackDice.attr('src', './assets/black_naked.png')
				}, 500)
			} else {			
				// compare the results
				// alter the DOM
				if (gameData.whiteOpener > gameData.blackOpener) {
				 	// if white goes first
					$openingRollMsg.text(gameData.whiteName + " goes first!")
					$openingBlackDice.attr('src', './assets/white_' + gameData.blackOpener.toString() + '.png')
				} else {
				 	// if black goes first
					$openingRollMsg.text(gameData.blackName + " goes first!")
					$openingWhiteDice.attr('src', './assets/black_' + gameData.whiteOpener.toString() + '.png')
				}
			}
		}

	} else {
		// for spectators, just render both rolls
		$whiteDiceLabel.text(gameData.whiteName)
		$blackDiceLabel.text(gameData.blackName)
		if (!!gameData.whiteOpener) {
			$openingWhiteDice.attr('src', './assets/white_' + gameData.whiteOpener.toString() + '.png')
		}
		if (!!gameData.blackOpener) {
			$openingBlackDice.attr('src', './assets/black_' + gameData.blackOpener.toString() + '.png')
		}
		if (!!gameData.whiteOpener && !! gameData.blackOpener){
			// if the results are equal, start the hell over
			if (gameData.whiteOpener === gameData.blackOpener) {
				// DOM stuff, everybody has to do this.
				$openingRollMsg.text("It's a tie, roll again.")
				setTimeout(function(){
					$openingWhiteDice.attr('src', './assets/white_naked.png')
					$openingBlackDice.attr('src', './assets/black_naked.png')
				}, 500)
			} else {			
				// compare the results
				// alter the DOM
				if (gameData.whiteOpener > gameData.blackOpener) {
				 	// if white goes first
					$openingRollMsg.text(gameData.whiteName + " goes first!")
					$openingBlackDice.attr('src', './assets/white_' + gameData.blackOpener.toString() + '.png')
				} else {
				 	// if black goes first
					$openingRollMsg.text(gameData.blackName + " goes first!")
					$openingWhiteDice.attr('src', './assets/black_' + gameData.whiteOpener.toString() + '.png')
				}
			}
		}
	}
//}

///// PHASE 3 and 4 are in gameplay.js /////

///// PHASE 5 /////

function endGame() {
	if (gameData.currentTurn !== myColor) {
		//unpack data
		board = unfirebasify(gameData.turnData)
		// render the board
		renderBoard(board)
	}
	// bring up the win modal for everybody
	setTimeout(function(){
		$gameWrapper.removeClass('active-wrapper')
		
		$gameEndModal.addClass('active-modal')
		$setUpWrapper.addClass('active-wrapper')
		if (gameData.winner === 'white') {
			$winnerNameSpan.text(gameData.whiteName)
			$loserNameSpan.text(gameData.blackName)
			$pcsHomeSpan.text((15 - gameData.blackPiecesHome).toString())
			$pcsBarSpan.text(gameData.barAtEnd)

		} else {
			$winnerNameSpan.text(gameData.blackName)
			$loserNameSpan.text(gameData.whiteName)
			$pcsHomeSpan.text((15 - gameData.whitePiecesHome).toString())
			$pcsBarSpan.text(gameData.barAtEnd)
		}

	}, 1500)
	// If I was a player, I get the option to play again or not.
	if (!!myColor) {
		$buttonHolder.append('<button id="play-again">Again</button>')
		$buttonHolder.append('<button id="leave-game">Quit</button>')
		$('#play-again').off()
		$('#play-again').addClass('active')
		$('#play-again').on('click', function(e){
			$('#play-again').off()
			$('#play-again').removeClass('active')
			$gameEndModal.removeClass('active-modal')
		//	$welcomeSetUpModal.addClass('active-modal')
			gameData.controllerToken = 2
			gameData.currentTurn = null
			gameData.currentRoll0 = null
			gameData.currentRoll1 = null
			gameData.whiteOpener = null
			gameData.blackOpener = null
			gameData.turnData = null
			gameData.whitePiecesHome = null
			gameData.blackPiecesHome = null
			gameData.winner = null
			gameData.barAtEnd = null
			gameData.lastMove = Date.now()

			databaseRef.set(gameData)
		})
		$('#leave-game').off()
		$('#leave-game').addClass('active')
		$('#leave-game').on('click', function(e){
			$('#leave-game').off()
			$('#leave-game').removeClass('active')
			$gameEndModal.removeClass('active-modal')
		//	$welcomeSetUpModal.addClass('active-modal')
			$('#your-name').remove()
			$setUpDiv.append('<form id="setup-form" action="#">\
				<input id="name-input" type="text" value="">\
				<input type="submit" id="submit-name"></form>')
		//	$opponentName.text('Waiting for opponent...')
			$yourStatusImg.prop('src', './assets/unready_white.png')
			$opponentStatusImg.prop('src', './assets/unready_black.png')  
			gameData.whiteName = ""
			gameData.blackName = ""
			gameData.controllerToken = 0
			gameData.currentTurn = null
			gameData.currentRoll0 = null
			gameData.currentRoll1 = null
			gameData.whiteOpener = null
			gameData.blackOpener = null
			gameData.turnData = null
			gameData.whitePiecesHome = null
			gameData.blackPiecesHome = null
			gameData.winner = null
			gameData.barAtEnd = null
			gameData.lastMove = null

			databaseRef.set(gameData)
		})
	}
}

///// Helper Functions /////

function openingDiceAnimate(color) {
	var dice = color === 'white' ? $openingWhiteDice : $openingBlackDice
	dice.attr('src', './assets/'+ color + '_' + 
							(Math.floor(Math.random() * 6) + 1).toString() + '.png') 
	setTimeout(function() {
		dice.attr('src', './assets/'+ color + '_' + 
							(Math.floor(Math.random() * 6) + 1).toString() + '.png') 
	    setTimeout(function() {
			dice.attr('src', './assets/'+ color + '_' + 
							(Math.floor(Math.random() * 6) + 1).toString() + '.png')
			setTimeout(function() {
			dice.attr('src', './assets/'+ color + '_' + 
							(Math.floor(Math.random() * 6) + 1).toString() + '.png')
				setTimeout(function() {
			dice.attr('src', './assets/'+ color + '_' + 
							(Math.floor(Math.random() * 6) + 1).toString() + '.png')
	    		}, 100)
	    	}, 100)
	    }, 100)
	}, 100)
}

// reset to a set of explicitly declared values in the database
function resetDatabase() {
	gameData.whiteName = ""
	gameData.blackName = ""
	gameData.controllerToken = 0
	gameData.currentTurn = null
	gameData.currentRoll0 = null
	gameData.currentRoll1 = null
	gameData.whiteOpener = null
	gameData.blackOpener = null
	gameData.turnData = null
	gameData.whitePiecesHome = null
	gameData.blackPiecesHome = null
	gameData.barAtEnd = null
	gameData.winner = null
	gameData.lastMove = null

	databaseRef.set(gameData)
}



});